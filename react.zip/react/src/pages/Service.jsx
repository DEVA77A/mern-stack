import React from 'react'
import Products from './Products'

const Service = () => {
  return (
    <div>
      <Products />
    </div>
  )
}

export default Service
